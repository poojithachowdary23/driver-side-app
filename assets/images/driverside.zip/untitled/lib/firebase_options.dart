import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    return const FirebaseOptions(
      apiKey: 'AIzaSyAizfmTuqj3rfWLYJD7t_BpnFTKgDopxCQ',
      authDomain: 'connekt2park-driver.firebaseapp.com',
      projectId: 'connekt2park-driver',
      storageBucket: 'connekt2park-driver.appspot.com',
      messagingSenderId: '24947425274',
      appId: '1:24947425274:android:464ed096bc3ec8abfdee43',
    );
  }
}
